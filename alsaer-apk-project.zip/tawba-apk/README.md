# السائر إلى الله — مشروع الـ APK

© 2026 جميع الحقوق محفوظة لـ أحمد العجمي.

## الطريقة الأسهل: بناء الـ APK على GitHub (بدون Android Studio)

1. أنشئ مستودعاً جديداً على GitHub (خاص private يكفي) وارفع كل محتويات هذا المجلد إليه، بما فيها المجلد المخفي `.github`.
2. افتح تبويب **Actions** في المستودع، واختر **Build APK**، ثم **Run workflow**.
3. بعد نحو ٥ إلى ١٠ دقائق افتح التشغيل المكتمل ونزّل الملف `alsaer-ila-allah-apk` من قسم Artifacts. بداخله `app-debug.apk`.
4. انقل الملف إلى جوالك وثبّته. سيطلب أندرويد السماح بالتثبيت من مصدر غير معروف، فوافق.

## الطريقة المحلية (تحتاج Node 20 وJDK 17 وAndroid SDK)

```bash
npm install
npx cap add android
npx capacitor-assets generate --android --iconBackgroundColor '#0e6a62' --iconBackgroundColorDark '#0a3d3a'
npx cap sync android
cd android && ./gradlew assembleDebug
```

الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات

- الـ APK الناتج موقّع بمفتاح التطوير (debug) ويصلح للتثبيت المباشر. للنشر على Google Play يلزم توقيع release بمفتاحك الخاص.
- التطبيق كله في `www/index.html`، وأي تعديل عليه ثم إعادة البناء يظهر في التطبيق.
- الخطوط تُحمَّل من الإنترنت عند توفره، وبدونه يستخدم خط النظام.
- الأيقونة (سجادة صلاة) في `assets/`.

# السائر إلى الله 2.1.0 — أساس الإنتاج

## قرارات المنتج المعتمدة
- حساب مستخدم ومزامنة سحابية.
- بيانات العادات والتعافي والسجلات خاصة بصاحب الحساب.
- الإدارة تحصل على إعدادات المحتوى وإحصائيات مجمعة فقط؛ لا توجد سياسة RLS تسمح لها بقراءة `user_private_data`.
- الاحتفاظ بمشروع V1 وV2 كما هما؛ هذا مجلد/فرع تطوير مستقل ولا يتطلب حذف التطبيق القديم.

## ما أُضيف في هذه المرحلة
1. مخطط Supabase لملفات المستخدمين والبيانات الخاصة مع Row Level Security.
2. طبقة أولية للمصادقة والمزامنة (`www/cloud-sync.js`) تستخدم جلسات Supabase.
3. ملف إعدادات منفصل (`www/cloud-config.js`) لا يحتوي أي أسرار.
4. تحميل SDK غير حاجب حتى لا يتوقف رسم واجهة التطبيق عند تعذر الشبكة.
5. إصلاح حساب سلسلة الالتزام في واجهة 2.1.0 الأساسية (من النسخة التأسيسية).

## ما لم يكتمل بعد — لا تعتبر الحزمة جاهزة للنشر
- شاشة التسجيل/الدخول/استعادة كلمة المرور لم تُربط بعد بواجهة التطبيق.
- لم تُنفذ بعد سياسة فض التعارض بين جهازين أو تشفير طرف-إلى-طرف.
- لم يُبن تطبيق Alsaer Admin بعد، ولم تُنشأ لوحة تحليلات مجمعة.
- لا يوجد مشروع Supabase فعلي أو مفاتيح أو بيئة إنتاج مرتبطة.
- لا تزال وظائف القرآن ومواقيت الصلاة والتنبيهات بحاجة إلى استكمال واختبار مصادرها.
- لم يُنتج APK موقّع بمفتاح إنتاج ولم يُختبر على أجهزة فعلية.

## إعداد بيئة Supabase التجريبية
1. أنشئ مشروع Supabase مستقلًا لـ 2.1.0، ولا تستخدم مشروعًا إنتاجيًا قبل المراجعة.
2. افتح SQL Editor وشغّل `backend/supabase/migrations/0001_private_account_data.sql`.
3. من Project Settings انسخ Project URL وPublishable/anon key.
4. ضع القيم في `www/cloud-config.js`:
   - `url`: رابط المشروع.
   - `anonKey`: المفتاح العام فقط.
5. لا تضع `service_role` أو أي مفتاح سري في تطبيق Android أو GitHub.
6. فعّل تأكيد البريد وسياسة كلمة مرور مناسبة وحدود محاولات الدخول في إعدادات Auth.
7. اختبر بحسابين مختلفين: يجب أن يفشل الحساب A في قراءة سجل الحساب B. اختبر ذلك من عميل المستخدم، وليس من service role الذي يتجاوز RLS.

## حماية البيانات والترحيل من V2
- لا تستبدل V1 أو V2 الآن.
- قبل تفعيل المزامنة لأي مستخدم، يجب بناء تدفق ترحيل يقرأ النسخة المحلية، يعرض معاينة للمستخدم، يأخذ نسخة احتياطية، ثم يرفعها للحساب بعد نجاح الدخول.
- لا نرفع بيانات محلية تلقائيًا فوق بيانات سحابية موجودة. يجب مقارنة timestamps وعرض خيار استعادة/دمج لتجنب الكتابة فوق سجل أحدث.
- لا ترسل ملاحظات المستخدم أو سجلات الانتكاس إلى التحليلات أو لوحة الإدارة.

## بناء Android
من `tawba-apk`:
```bash
npm install
npm run build
```
ثم البناء من Android Studio أو GitHub Actions. يجب توقيع APK/AAB بمفتاح إنتاج محفوظ بأمان خارج المستودع.


## Google sign-in (OAuth) — integration preparation
- Settings now includes a "Continue with Google" action using Supabase OAuth provider `google`.
- In Supabase Authentication > Providers, enable Google and enter the OAuth Client ID/Secret from Google Cloud Console.
- In Google Cloud Console, configure the OAuth consent screen and add the Supabase callback URL shown in Supabase provider settings (normally `https://<project-ref>.supabase.co/auth/v1/callback`).
- In Supabase Authentication > URL Configuration, add the app's HTTPS production URL to Site URL and Redirect URLs. Add the exact app deep-link scheme only after Android applicationId and verified Android App Links/deep-link configuration are finalized.
- Fill `www/cloud-config.js` with Supabase Project URL and public anon/publishable key. Never commit OAuth client secret or Supabase service-role key.
- Google sign-in is not live until these external console settings and a real OAuth round-trip are tested on Android.

## Interactive notifications — current scope
- Settings now provides notification permission, a test notification, and a persistent in-app notification center with Open and Dismiss actions.
- Android local notification scheduling uses `@capacitor/local-notifications` when the native plugin is installed; browser Notification API is a fallback.
- This is local/device notification support. Remote push campaigns, server-triggered notifications, FCM token registration, delivery analytics, and action buttons from a killed/background app require Firebase Cloud Messaging plus a trusted server/edge function and are NOT complete in this package.
- Do not promise reminders at exact times until timezone, Android notification permission, battery optimization, reboot rescheduling, and device tests are complete.

## Safe account migration
- The initial "Sync my data" action uploads the existing local `tawba_v1` data only if the account has no cloud row.
- If a cloud row already exists, the action refuses to overwrite it. A conflict-safe merge/restore screen must be built before multi-device bidirectional sync is enabled.
- This prevents a first login on a second device from silently overwriting either side.
